G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-08-19T13:20:03+05:45*
G04 #@! TF.ProjectId,SmartTap,536d6172-7454-4617-902e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-19 13:20:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.218750X-0.112544X0.317568X-0.331294X-0.061318X0.112544X-0.317568X0.331294X0.061318X0*%
%ADD11RoundRect,0.218750X-0.256250X0.218750X-0.256250X-0.218750X0.256250X-0.218750X0.256250X0.218750X0*%
%ADD12RoundRect,0.218750X-0.324689X0.089959X-0.139794X-0.306551X0.324689X-0.089959X0.139794X0.306551X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D2*
X172030001Y-74600000D03*
X171242499Y-75963992D03*
G04 #@! TD*
D11*
G04 #@! TO.C,D3*
X183500000Y-63925000D03*
X183500000Y-65500000D03*
G04 #@! TD*
G04 #@! TO.C,D1*
X172800000Y-63925000D03*
X172800000Y-65500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D4*
X184167188Y-74616283D03*
X184832812Y-76043717D03*
G04 #@! TD*
M02*
